const User = require("../models/User");
const Login = require("../models/Login");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");


// Function to generate username
const generateUsername = (name, phoneNumber, userType) => {
  return `${name.toLowerCase()}_${phoneNumber.slice(-4)}_${userType}`; // Example: john_1234_customer
};

// Register User
const registerUser = async (req, res) => {
  try {
    const { name, email, phoneNumber, location, userType, password } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ phoneNumber });
    if (existingUser) return res.status(400).json({ message: "User already exists" });

    // Generate unique username
    let username = generateUsername(name, phoneNumber, userType);

    // Ensure username is unique
    let userExists = await User.findOne({ username });
    let counter = 1;
    while (userExists) {
      username = `${generateUsername(name, phoneNumber, userType)}_${counter}`;
      userExists = await User.findOne({ username });
      counter++;
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create and save user
    const newUser = new User({
      name,
      email,
      phoneNumber,
      location,
      userType,
      password: hashedPassword,
      username,
    });
    await newUser.save();

    // Save login credentials in Login collection
    const newLogin = new Login({
      username,
      userType,
      password: hashedPassword,
    });
    await newLogin.save();

    res.status(201).json({ message: "User registered successfully", username });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// User Login
const loginUser = async (req, res) => {
  try {
    const { username, password } = req.body;

    // Check if user exists
    const user = await Login.findOne({ username });
    if (!user) {
      return res.status(400).json({ message: "Invalid username or password" });
    }

    // Compare hashed password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid username or password" });
    }

    // Generate JWT token
    const token = jwt.sign(
      { username: user.username, userType: user.userType },
      process.env.JWT_SECRET,
      { expiresIn: "1d" } // Token expires in 1 day
    );

    res.json({ message: "Login successful", token, userType: user.userType });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


module.exports = { registerUser , loginUser};
